import React from 'react';
import { ArrowLeft, Check, ShieldCheck } from 'lucide-react';
import { PolicySection } from '../types';

interface PolicyPageViewProps {
  policy: PolicySection;
  onBack: () => void;
}

export const PolicyPageView: React.FC<PolicyPageViewProps> = ({ policy, onBack }) => {
  return (
    <div className="w-full max-w-4xl mx-auto px-4 py-6 animate-fadeIn">
      {/* Top Navigation */}
      <button
        type="button"
        onClick={onBack}
        className="inline-flex items-center gap-2 text-sm font-semibold text-blue-600 hover:text-blue-800 transition-colors py-1.5 px-3 rounded-lg hover:bg-blue-50 cursor-pointer mb-6"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back to Home</span>
      </button>

      {/* Policy Page Header */}
      <div className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-8 shadow-xs mb-6">
        <span className="text-xs font-bold text-blue-600 uppercase tracking-wider">
          Legal &amp; Compliance Policy
        </span>
        <h1 className="text-2xl sm:text-3xl font-black text-black mt-1 mb-2">
          {policy.title}
        </h1>
        <p className="text-sm sm:text-base text-slate-600 leading-relaxed font-medium">
          {policy.summary}
        </p>
      </div>

      {/* Policy Clauses */}
      <div className="space-y-6">
        {policy.content.map((clause, idx) => (
          <div
            key={idx}
            className="bg-white border border-slate-200 rounded-2xl p-6 sm:p-7 shadow-xs"
          >
            <h2 className="text-lg font-bold text-black flex items-center gap-2.5 mb-4">
              <span className="w-2.5 h-2.5 rounded-full bg-blue-600 shrink-0" />
              {clause.heading}
            </h2>

            <ul className="space-y-3 mb-4">
              {clause.points.map((pt, pIdx) => (
                <li
                  key={pIdx}
                  className="text-sm text-slate-700 flex items-start gap-2.5 leading-relaxed"
                >
                  <Check className="w-4 h-4 text-emerald-600 shrink-0 mt-1" />
                  <span>{pt}</span>
                </li>
              ))}
            </ul>

            {clause.legalNote && (
              <div className="pt-3 mt-3 border-t border-slate-100 text-xs font-medium text-slate-500 italic">
                Statutory Reference: {clause.legalNote}
              </div>
            )}
          </div>
        ))}
      </div>

      {/* Statutory Footer Guarantee */}
      <div className="mt-8 bg-blue-50 border border-blue-200 rounded-2xl p-5 flex items-start gap-3.5 text-xs text-blue-900">
        <ShieldCheck className="w-5 h-5 text-blue-600 shrink-0 mt-0.5" />
        <div>
          <strong className="font-bold">Official Statutory Guarantee:</strong>
          <p className="mt-1 text-blue-800 leading-relaxed">
            All documents prepared through Cotrix Tax &amp; Compliance Group (CTC) strictly adhere to the Indian Stamp Act, 1899, relevant State Stamp Rules, and the Digital Personal Data Protection (DPDP) Act, 2023.
          </p>
        </div>
      </div>

      {/* Bottom Back Button */}
      <div className="mt-8 pt-4 flex justify-center">
        <button
          type="button"
          onClick={onBack}
          className="px-6 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm rounded-xl transition-colors cursor-pointer shadow-xs"
        >
          Back to Home
        </button>
      </div>
    </div>
  );
};
