import { PolicySection } from '../types';

export const POLICIES_DATA: PolicySection[] = [
  {
    id: 'payment-policy',
    title: 'Payment & Billing Policy',
    summary: 'Pay after verified document delivery for standard consumer orders; authorized UPI and digital gateway channels; advance token mandate for high-value orders.',
    content: [
      {
        heading: '1. Post-Delivery Payment Guarantee',
        points: [
          'Under standard consumer orders, client payment is requested only after the drafted legal document or affidavit draft is delivered to the client for verification.',
          'Clients receive a watermarked preview copy and confirmation of official state e-stamp procurement before paying the service balance.',
          'Payment must be cleared promptly upon receipt of the document via verified official links.'
        ],
        legalNote: 'Delivery implies digital transmission via registered email, WhatsApp, or user dashboard in PDF format.'
      },
      {
        heading: '2. High-Value & Risk Assessment Safeguard (>₹300 - ₹400 Threshold)',
        points: [
          'For orders exceeding ₹300 - ₹400 in aggregate value (including high-denomination stamp paper like ₹500 or complex custom partnership/lease drafts), Cotrix Tax & Compliance Group (CTC) reserves the absolute discretion to require partial or full advance token payment prior to purchasing non-refundable government e-stamp paper.',
          'If automated fraud-detection or a compliance officer flags an application as suspicious, anonymous, unverified, or high-risk, CTC reserves the unconditional right to mandate KYC verification and upfront payment.',
          'Government e-Stamp duty paid to state treasuries is non-refundable by government rules once printed in the applicant’s name.'
        ],
        legalNote: 'Clause compliant with Indian Contract Act 1872 Section 73 (mitigation of losses on customized non-recoverable stamp duty).'
      },
      {
        heading: '3. Authorized Payment Modes & Digital Channels',
        points: [
          'We exclusively accept payments via authorized digital instruments: UPI (Google Pay, PhonePe, Paytm, BHIM), Debit/Credit Cards, Net Banking, and authorized instant payment links.',
          'Never pay any private account not explicitly bearing the verified trade name "COTRIX TAX & COMPLIANCE GROUP" or "CTC Legal".',
          'GST-compliant tax invoices are issued automatically with every transaction.'
        ],
        legalNote: 'In accordance with PMLA guidelines and GST Act 2017, cash transactions over prescribed limits are strictly prohibited.'
      }
    ]
  },
  {
    id: 'security-vault-policy',
    title: 'Data Security & Storage Vault Policy',
    summary: 'Zero plaintext database storage of sensitive KYC; admin-encrypted vaulting; official DigiLocker and State Government e-Stamp portal processing.',
    content: [
      {
        heading: '1. Zero Permanent Plaintext Database Storage',
        points: [
          'CTC strictly prohibits the permanent storage of sensitive client documents (Aadhaar cards, PAN copies, property deeds, biometric logs) in accessible public web databases.',
          'Only essential non-sensitive administrative identifiers (such as applicant name, contact phone, and order serial ID) are retained for billing reconciliation.',
          'In the improbable event of an external cyber incident or malicious intrusion against internet servers, your confidential identity documents cannot be leaked because they are never kept on public databases.'
        ],
        legalNote: 'Adheres to Digital Personal Data Protection (DPDP) Act 2023 and ISO/IEC 27001 data minimization standards.'
      },
      {
        heading: '2. The Restricted Admin Vault Protocol',
        points: [
          'Sensitive files uploaded for stamp duty computation are routed immediately into an AES-256 encrypted, isolated temporary Admin Vault.',
          'This vault can only be accessed by authorized senior compliance officers holding cryptographic two-factor authorization keys.',
          'The officer accesses the official State Government e-Stamp Portal (Stock Holding Corporation of India Ltd. / State Treasury Portals) to procure the official non-judicial stamp certificate.',
          'The front stamp paper is professionally merged with the legally formatted deed contents into standardized A4 legal dimensions.'
        ],
        legalNote: 'All administrative sessions are cryptographically logged with immutable timestamps.'
      },
      {
        heading: '3. DigiLocker & Government Portal e-Sign Integration',
        points: [
          'For paperless execution, the completed document is prepared for Aadhaar-based DigiLocker e-Sign portals regulated under Information Technology Act 2000.',
          'Clients sign directly on the official Government portal or UIDAI-approved e-Sign gateway using OTP.',
          'Once execution is completed and final delivery is fulfilled, temporary staging records in the vault are systematically scrubbed.'
        ],
        legalNote: 'Electronic signatures executed via UIDAI e-Sign carry identical evidentiary value to wet-ink signatures under Section 5 of the IT Act 2000.'
      }
    ]
  },
  {
    id: 'delivery-policy',
    title: 'Delivery & Express Fast-Track Policy',
    summary: 'Standard 24-hour turnaround; dynamic urgent speed-up at ₹5/hour saved; strict minimum 2-hour legal processing floor.',
    content: [
      {
        heading: '1. Standard 24-Hour Delivery Timeline',
        points: [
          'All standard agreement and affidavit requests are guaranteed for legal drafting and digital dispatch within 24 business hours from receipt of requisite details.',
          'Delivery is effected across PAN-India via instant high-resolution digital format (PDF ready for print and e-sign) with optional physical courier dispatch where opted.'
        ],
        legalNote: 'Delivery timelines begin once all mandatory legal particulars (names, addresses, stamp values) have been submitted.'
      },
      {
        heading: '2. Express Urgent Fast-Track Calculation',
        points: [
          'Need your document faster than 24 hours? CTC offers an instant legal express service.',
          'Our transparent urgent pricing operates at exactly ₹5 per hour expedited from the 24-hour baseline:',
          '• 23 Hours delivery = Base Price + ₹5 (1 hour expedited)',
          '• 22 Hours delivery = Base Price + ₹10 (2 hours expedited)',
          '• 18 Hours delivery = Base Price + ₹30 (6 hours expedited)',
          '• 12 Hours delivery = Base Price + ₹60 (12 hours expedited)',
          '• 2 Hours delivery (Maximum Speed) = Base Price + ₹110 (22 hours expedited)'
        ],
        legalNote: 'Fast-track priority schedules an assigned attorney immediately to your docket.'
      },
      {
        heading: '3. Absolute Minimum 2-Hour Processing Floor',
        points: [
          'Under no circumstances can an agreement or affidavit be generated in less than two (2) hours.',
          'This 2-hour minimum floor is legally mandatory to permit verified conflict check, official State treasury stamp purchase verification, and advocate quality inspection.',
          'If you have extraordinary emergency court or travel requirements, please call our 24/7 dedicated helpline directly.'
        ],
        legalNote: 'Guarantees that express drafting never compromises evidentiary validity before courts and registrar offices.'
      }
    ]
  },
  {
    id: 'legal-registration-policy',
    title: 'Government Registration & Statutory Compliance',
    summary: '100% Government Registered firm under GST and MSME (UDYAM); compliance with Indian Stamp Act 1899 and Notaries Act.',
    content: [
      {
        heading: '1. 100% Government Registered Entity',
        points: [
          'Cotrix Tax & Compliance Group (CTC) is a formally registered legal and tax compliance entity under the Government of India.',
          'Registered under the Ministry of Micro, Small and Medium Enterprises (MSME UDYAM Registration) and the Central Goods and Services Tax Act (GSTIN Registration).',
          'All services rendered comply with statutory Indian federal and provincial guidelines.'
        ],
        legalNote: 'Official GSTIN and MSME registration certificates can be verified through the Settings panel.'
      },
      {
        heading: '2. Official e-Stamp Paper Authenticity Guarantee',
        points: [
          'Every e-stamp paper issued through our network is procured directly from Government-authorized central record keeping agencies (Stock Holding Corporation of India Ltd. - SHCIL or State Treasury portals).',
          'Each e-stamp carries an unalterable Certificate Number, unique QR code, barcode, issue date, and traceable government treasury receipt.',
          'Any court, registrar, bank, or embassy can instantly verify the authenticity of the e-stamp on the official government web portal.'
        ],
        legalNote: 'Issued under the Indian Stamp Act, 1899 and relevant State Stamp Rules of the respective State jurisdiction.'
      },
      {
        heading: '3. Evidentiary Weight & Legal Non-Liability Disclaimer',
        points: [
          'CTC acts as a professional legal facilitation, e-stamping, and drafting service based on user-provided factual representations.',
          'Deponents and parties are strictly responsible for the truthfulness of facts stated in affidavits and declarations. Providing false statements under oath is punishable under Indian penal statutes.',
          'CTC disclaims liability for any deliberate misstatement, impersonation, or forgery initiated by an applicant.'
        ],
        legalNote: 'Affidavits must be sworn truthfully by the deponent.'
      }
    ]
  },
  {
    id: 'contact-policy',
    title: '24/7 Contact & Customer Support Policy',
    summary: 'Round-the-clock 24/7 telephonic helpline, instant WhatsApp desk, ticket escalation, and priority dispute resolution.',
    content: [
      {
        heading: '1. Round-The-Clock 24/7 Telephonic Support',
        points: [
          'Our legal assistance helpdesk is active 24 hours a day, 7 days a week, 365 days a year without holidays.',
          'Direct Emergency Helpline: +91 98765 43210',
          'Secondary Desk & WhatsApp Assistance: +91 98765 43211',
          'Official Support Email: support@cotrixtax.com / compliance@cotrixtax.com'
        ],
        legalNote: 'Calls may be recorded for quality assurance and fraud prevention.'
      },
      {
        heading: '2. Dedicated Dispute & Escalation Matrix',
        points: [
          'Tier 1: Instant chat & helpline resolution within 15 minutes.',
          'Tier 2: Advocate review of drafting requirements within 1 hour.',
          'Tier 3: Senior compliance manager escalation for high-value contracts within 3 hours.'
        ],
        legalNote: 'All inquiries receive a verifiable digital docket ticket ID.'
      },
      {
        heading: '3. Pan-India Physical & Regional Service Network',
        points: [
          'Headquarters: CTC Tower, Corporate Boulevard, Sector 62, Noida, NCR Delhi 201309.',
          'Regional Liaison Desks: Mumbai, Bengaluru, Kolkata, Jaipur, Lucknow, Hyderabad, Ahmedabad, and Chandigarh.',
          'Physical stamp paper courier service available for all 28 States and 8 Union Territories.'
        ],
        legalNote: 'Jurisdiction for legal arbitration shall strictly reside in the courts of New Delhi / Gautam Buddha Nagar.'
      }
    ]
  }
];
