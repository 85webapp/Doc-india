// Multilingual Voice Explainer & Speech Synthesis Data for Legal Wizards
// Sweet, conversational Hindi & multilingual spoken explanations explaining what to enter and why

export type SupportedLanguage = 'hi' | 'en' | 'mr' | 'gu' | 'ml' | 'ta' | 'te' | 'bn' | 'kn' | 'pa';

export interface LanguageOption {
  code: SupportedLanguage;
  name: string;
  nativeName: string;
  speechCode: string;
}

export const SUPPORTED_LANGUAGES: LanguageOption[] = [
  { code: 'hi', name: 'Hindi', nativeName: 'हिंदी', speechCode: 'hi-IN' },
  { code: 'en', name: 'English (Conversational)', nativeName: 'English / Hinglish', speechCode: 'en-IN' },
  { code: 'mr', name: 'Marathi', nativeName: 'मराठी', speechCode: 'mr-IN' },
  { code: 'gu', name: 'Gujarati', nativeName: 'ગુજરાતી', speechCode: 'gu-IN' },
  { code: 'pa', name: 'Punjabi', nativeName: 'ਪੰਜਾਬੀ', speechCode: 'pa-IN' },
  { code: 'ml', name: 'Malayalam', nativeName: 'മലയാളം', speechCode: 'ml-IN' },
  { code: 'ta', name: 'Tamil', nativeName: 'தமிழ்', speechCode: 'ta-IN' },
  { code: 'te', name: 'Telugu', nativeName: 'తెలుగు', speechCode: 'te-IN' },
  { code: 'bn', name: 'Bengali', nativeName: 'বাংলা', speechCode: 'bn-IN' },
  { code: 'kn', name: 'Kannada', nativeName: 'ಕನ್ನಡ', speechCode: 'kn-IN' }
];

// Narration text is generated dynamically by the server-side Gemini endpoints.

class SpeechController {
  private currentUtterance: SpeechSynthesisUtterance | null = null;
  private isSpeakingState = false;
  private listeners: ((speaking: boolean) => void)[] = [];

  constructor() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.onvoiceschanged = () => {
      };
    }
  }

  public subscribe(fn: (speaking: boolean) => void) {
    this.listeners.push(fn);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== fn);
    };
  }

  private notify(state: boolean) {
    this.isSpeakingState = state;
    this.listeners.forEach((fn) => fn(state));
  }

  public speak(text: string, langCode: string) {
    if (typeof window === 'undefined' || !('speechSynthesis' in window)) {
      return;
    }

    this.stop();

    const cleanText = text.replace(/[*_#]/g, '').trim();
    if (!cleanText) return;

    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.lang = langCode;
    // Sweet, natural, relaxed pace
    utterance.rate = 0.92;
    utterance.pitch = 1.05;

    // Pick best matching natural voice
    const voices = window.speechSynthesis.getVoices();
    if (voices && voices.length > 0) {
      const prefix = langCode.split('-')[0].toLowerCase();
      // Try exact match or language prefix match
      const matchingVoice =
        voices.find((v) => v.lang.toLowerCase() === langCode.toLowerCase()) ||
        voices.find((v) => v.lang.toLowerCase().startsWith(prefix));

      if (matchingVoice) {
        utterance.voice = matchingVoice;
      }
    }

    utterance.onstart = () => {
      this.notify(true);
    };

    utterance.onend = () => {
      this.notify(false);
      this.currentUtterance = null;
    };

    utterance.onerror = () => {
      this.notify(false);
      this.currentUtterance = null;
    };

    this.currentUtterance = utterance;
    window.speechSynthesis.speak(utterance);
  }

  public stop() {
    if (typeof window !== 'undefined' && 'speechSynthesis' in window) {
      window.speechSynthesis.cancel();
    }
    this.currentUtterance = null;
    this.notify(false);
  }

  public isSpeaking(): boolean {
    return this.isSpeakingState;
  }
}

export const speechController = new SpeechController();

// Preferences & Storage Key for Audio Explainer Language
export const AUDIO_LANG_STORAGE_KEY = 'ctc_audio_language_v2';

export function getStoredAudioLanguage(): SupportedLanguage {
  try {
    const saved = localStorage.getItem(AUDIO_LANG_STORAGE_KEY) as SupportedLanguage;
    if (saved && SUPPORTED_LANGUAGES.some((l) => l.code === saved)) {
      return saved;
    }
  } catch {}
  return 'hi'; // Default Hindi
}

export function setStoredAudioLanguage(lang: SupportedLanguage) {
  try {
    localStorage.setItem(AUDIO_LANG_STORAGE_KEY, lang);
    window.dispatchEvent(new CustomEvent('ctc_audio_language_changed', { detail: { lang } }));
  } catch {}
}

/** Collect visible form labels from the active document wizard, not hidden templates. */
export function getVisibleFormLabels(): string[] {
  if (typeof document === 'undefined') return [];
  const roots = Array.from(document.querySelectorAll<HTMLElement>('[data-document-wizard]'))
    .filter((el) => el.getClientRects().length > 0);
  const root = roots[0] || document.body;
  const selectors = 'label, legend, [aria-label], [data-field-label], .field-label';
  const seen = new Set<string>();
  return Array.from(root.querySelectorAll<HTMLElement>(selectors))
    .filter((el) => el.getClientRects().length > 0)
    .map((el) => (el.innerText || el.getAttribute('aria-label') || el.getAttribute('data-field-label') || '').replace(/\s+/g, ' ').trim())
    .filter((text) => text.length > 1 && text.length < 180)
    .filter((text) => { const key = text.toLocaleLowerCase(); if (seen.has(key)) return false; seen.add(key); return true; })
    .slice(0, 80);
}

/** Resolve the real visible label for a speaker button's field key when possible. */
export function getVisibleFieldLabel(fieldKey: string): string {
  if (typeof document !== 'undefined') {
    const key = fieldKey.toLowerCase().replace(/[^a-z0-9]/g, '');
    const controls = Array.from(document.querySelectorAll<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>('input, select, textarea'));
    for (const control of controls) {
      const controlKey = `${control.id} ${control.name} ${control.getAttribute('data-field-key') || ''}`.toLowerCase().replace(/[^a-z0-9]/g, '');
      if (controlKey && (controlKey.includes(key) || key.includes(controlKey))) {
        if (control.id) {
          const label = document.querySelector<HTMLLabelElement>(`label[for="${CSS.escape(control.id)}"]`);
          if (label?.innerText.trim()) return label.innerText.replace(/\s+/g, ' ').trim();
        }
        const parentLabel = control.closest('label');
        if (parentLabel?.innerText.trim()) return parentLabel.innerText.replace(/\s+/g, ' ').trim();
        const aria = control.getAttribute('aria-label');
        if (aria) return aria.trim();
      }
    }
  }
  return fieldKey.replace(/[-_]/g, ' ').replace(/([a-z])([A-Z])/g, '$1 $2').replace(/\b\w/g, (c) => c.toUpperCase());
}

export interface SearchIntentResult {
  refusal: boolean;
  forbiddenCategory?: string;
  refusalReason?: string;
  spokenText: string;
  matches: Array<{
    id: string;
    title: string;
    category: string;
    matchScore: number;
    explanation: string;
  }>;
}

// 1. Search Document Intent via Gemini backend
export async function searchDocumentIntent(
  query: string,
  audioLanguage?: SupportedLanguage
): Promise<SearchIntentResult | null> {
  const lang = audioLanguage || getStoredAudioLanguage();
  try {
    const res = await fetch('/api/gemini/search', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ query, audioLanguage: lang })
    });
    if (!res.ok) {
      throw new Error(`Server returned ${res.status}`);
    }
    return await res.json();
  } catch (err) {
    console.warn('Gemini search request failed:', err);
    return null;
  }
}

// 2. Dynamic Contextual Page Explainer via Gemini backend
export async function fetchPageExplanation(
  documentTitle: string,
  pageNumber: number,
  pageTitle: string,
  fields: string[] = [],
  audioLanguage?: SupportedLanguage
): Promise<string> {
  const lang = audioLanguage || getStoredAudioLanguage();
  try {
    const res = await fetch('/api/gemini/explain-page', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ documentTitle, pageNumber, pageTitle, fields, audioLanguage: lang })
    });
    if (res.ok) {
      const data = await res.json();
      if (data.spokenText) return data.spokenText;
    }
  } catch (err) {
    console.warn('Gemini page explanation request failed:', err);
  }
  return '';
}

// 3. Dynamic Contextual Field Explainer via Gemini backend
export async function fetchFieldExplanation(
  documentTitle: string,
  fieldKey: string,
  fieldLabel: string,
  context = '',
  audioLanguage?: SupportedLanguage
): Promise<string> {
  const lang = audioLanguage || getStoredAudioLanguage();
  try {
    const res = await fetch('/api/gemini/explain-field', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ documentTitle, fieldKey, fieldLabel, context, audioLanguage: lang })
    });
    if (res.ok) {
      const data = await res.json();
      if (data.spokenText) return data.spokenText;
    }
  } catch (err) {
    console.warn('Gemini field explanation request failed:', err);
  }
  return '';
}

